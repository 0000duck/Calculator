﻿namespace BestCalculator
{
    partial class Calculator
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Calculator));
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button0 = new System.Windows.Forms.Button();
            this.buttonDot = new System.Windows.Forms.Button();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.buttonMinus = new System.Windows.Forms.Button();
            this.buttonMulti = new System.Windows.Forms.Button();
            this.buttonDivide = new System.Windows.Forms.Button();
            this.buttonEqual = new System.Windows.Forms.Button();
            this.buttonToZero = new System.Windows.Forms.Button();
            this.buttonToLeft = new System.Windows.Forms.Button();
            this.buttonPN = new System.Windows.Forms.Button();
            this.buttonRoot = new System.Windows.Forms.Button();
            this.textAnswer = new System.Windows.Forms.TextBox();
            this.textExpression = new System.Windows.Forms.TextBox();
            this.buttonInvisible = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this.button1, "button1");
            this.button1.Name = "button1";
            this.button1.TabStop = false;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this.button2, "button2");
            this.button2.Name = "button2";
            this.button2.TabStop = false;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this.button3, "button3");
            this.button3.Name = "button3";
            this.button3.TabStop = false;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this.button4, "button4");
            this.button4.Name = "button4";
            this.button4.TabStop = false;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this.button5, "button5");
            this.button5.Name = "button5";
            this.button5.TabStop = false;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this.button6, "button6");
            this.button6.Name = "button6";
            this.button6.TabStop = false;
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this.button7, "button7");
            this.button7.Name = "button7";
            this.button7.TabStop = false;
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this.button8, "button8");
            this.button8.Name = "button8";
            this.button8.TabStop = false;
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this.button9, "button9");
            this.button9.Name = "button9";
            this.button9.TabStop = false;
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button0
            // 
            this.button0.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this.button0, "button0");
            this.button0.Name = "button0";
            this.button0.TabStop = false;
            this.button0.UseVisualStyleBackColor = false;
            this.button0.Click += new System.EventHandler(this.button0_Click);
            // 
            // buttonDot
            // 
            this.buttonDot.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this.buttonDot, "buttonDot");
            this.buttonDot.Name = "buttonDot";
            this.buttonDot.TabStop = false;
            this.buttonDot.UseVisualStyleBackColor = false;
            this.buttonDot.Click += new System.EventHandler(this.buttonDot_Click);
            // 
            // buttonAdd
            // 
            resources.ApplyResources(this.buttonAdd, "buttonAdd");
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.TabStop = false;
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // buttonMinus
            // 
            resources.ApplyResources(this.buttonMinus, "buttonMinus");
            this.buttonMinus.Name = "buttonMinus";
            this.buttonMinus.TabStop = false;
            this.buttonMinus.UseVisualStyleBackColor = true;
            this.buttonMinus.Click += new System.EventHandler(this.buttonMinus_Click);
            // 
            // buttonMulti
            // 
            resources.ApplyResources(this.buttonMulti, "buttonMulti");
            this.buttonMulti.Name = "buttonMulti";
            this.buttonMulti.TabStop = false;
            this.buttonMulti.UseVisualStyleBackColor = true;
            this.buttonMulti.Click += new System.EventHandler(this.buttonMulti_Click);
            // 
            // buttonDivide
            // 
            resources.ApplyResources(this.buttonDivide, "buttonDivide");
            this.buttonDivide.Name = "buttonDivide";
            this.buttonDivide.TabStop = false;
            this.buttonDivide.UseVisualStyleBackColor = true;
            this.buttonDivide.Click += new System.EventHandler(this.buttonDivide_Click);
            // 
            // buttonEqual
            // 
            resources.ApplyResources(this.buttonEqual, "buttonEqual");
            this.buttonEqual.Name = "buttonEqual";
            this.buttonEqual.TabStop = false;
            this.buttonEqual.UseVisualStyleBackColor = true;
            this.buttonEqual.Click += new System.EventHandler(this.buttonEqual_Click);
            // 
            // buttonToZero
            // 
            resources.ApplyResources(this.buttonToZero, "buttonToZero");
            this.buttonToZero.Name = "buttonToZero";
            this.buttonToZero.TabStop = false;
            this.buttonToZero.UseVisualStyleBackColor = true;
            this.buttonToZero.Click += new System.EventHandler(this.buttonToZero_Click);
            // 
            // buttonToLeft
            // 
            resources.ApplyResources(this.buttonToLeft, "buttonToLeft");
            this.buttonToLeft.Name = "buttonToLeft";
            this.buttonToLeft.TabStop = false;
            this.buttonToLeft.UseVisualStyleBackColor = true;
            this.buttonToLeft.Click += new System.EventHandler(this.buttonToLeft_Click);
            // 
            // buttonPN
            // 
            this.buttonPN.BackColor = System.Drawing.SystemColors.ControlLight;
            resources.ApplyResources(this.buttonPN, "buttonPN");
            this.buttonPN.Name = "buttonPN";
            this.buttonPN.TabStop = false;
            this.buttonPN.UseVisualStyleBackColor = false;
            this.buttonPN.Click += new System.EventHandler(this.buttonPN_Click);
            // 
            // buttonRoot
            // 
            resources.ApplyResources(this.buttonRoot, "buttonRoot");
            this.buttonRoot.Name = "buttonRoot";
            this.buttonRoot.TabStop = false;
            this.buttonRoot.UseVisualStyleBackColor = true;
            this.buttonRoot.Click += new System.EventHandler(this.buttonRoot_Click);
            // 
            // textAnswer
            // 
            this.textAnswer.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textAnswer.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textAnswer.CausesValidation = false;
            resources.ApplyResources(this.textAnswer, "textAnswer");
            this.textAnswer.Name = "textAnswer";
            this.textAnswer.UseWaitCursor = true;
            // 
            // textExpression
            // 
            this.textExpression.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textExpression.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textExpression.CausesValidation = false;
            resources.ApplyResources(this.textExpression, "textExpression");
            this.textExpression.Name = "textExpression";
            // 
            // buttonInvisible
            // 
            resources.ApplyResources(this.buttonInvisible, "buttonInvisible");
            this.buttonInvisible.Name = "buttonInvisible";
            this.buttonInvisible.TabStop = false;
            this.buttonInvisible.UseVisualStyleBackColor = true;
            this.buttonInvisible.Click += new System.EventHandler(this.buttonInvisible_Click);
            // 
            // Calculator
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Controls.Add(this.buttonInvisible);
            this.Controls.Add(this.textExpression);
            this.Controls.Add(this.textAnswer);
            this.Controls.Add(this.buttonRoot);
            this.Controls.Add(this.buttonPN);
            this.Controls.Add(this.buttonToLeft);
            this.Controls.Add(this.buttonToZero);
            this.Controls.Add(this.buttonEqual);
            this.Controls.Add(this.buttonDivide);
            this.Controls.Add(this.buttonMulti);
            this.Controls.Add(this.buttonMinus);
            this.Controls.Add(this.buttonAdd);
            this.Controls.Add(this.buttonDot);
            this.Controls.Add(this.button0);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.KeyPreview = true;
            this.Name = "Calculator";
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Calculator_KeyPress);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button0;
        private System.Windows.Forms.Button buttonDot;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.Button buttonMinus;
        private System.Windows.Forms.Button buttonMulti;
        private System.Windows.Forms.Button buttonDivide;
        private System.Windows.Forms.Button buttonEqual;
        private System.Windows.Forms.Button buttonToZero;
        private System.Windows.Forms.Button buttonToLeft;
        private System.Windows.Forms.Button buttonPN;
        private System.Windows.Forms.Button buttonRoot;
        private System.Windows.Forms.TextBox textAnswer;
        private System.Windows.Forms.TextBox textExpression;
        private System.Windows.Forms.Button buttonInvisible;
    }
}

